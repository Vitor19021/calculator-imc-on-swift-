

import SwiftUI

@main
struct IMC: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
