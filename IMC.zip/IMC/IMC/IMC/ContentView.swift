import SwiftUI

struct ContentView: View {
    @State private var peso: String = ""
    @State private var altura: String = ""
    @State private var resultadoIMC: String = ""

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Digite seu peso (kg)", text: $peso)
                    .keyboardType(.decimalPad)
                    .padding()
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray, lineWidth: 1))

                TextField("Digite sua altura (m)", text: $altura)
                    .keyboardType(.decimalPad)
                    .padding()
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray, lineWidth: 1))

                Button(action: calcularIMC) {
                    Text("Calcular IMC")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }

                Text(resultadoIMC)
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .padding()

                Spacer()
            }
            .padding()
            .navigationTitle("Calculadora de IMC")
        }
    }

    func calcularIMC() {
        guard let peso = Double(peso), let altura = Double(altura), altura > 0 else {
            resultadoIMC = "Por favor, insira valores válidos."
            return
        }

        let imc = peso / (altura * altura)

        switch imc {
        case ..<18.5:
            resultadoIMC = "IMC: \(String(format: "%.2f", imc)) (Abaixo do Peso)"
        case 18.5..<25:
            resultadoIMC = "IMC: \(String(format: "%.2f", imc)) (Peso Normal)"
        case 25..<30:
            resultadoIMC = "IMC: \(String(format: "%.2f", imc)) (Excesso de Peso)"
        case 30..<35:
            resultadoIMC = "IMC: \(String(format: "%.2f", imc)) (Obesidade I)"
        case 35..<40:
            resultadoIMC = "IMC: \(String(format: "%.2f", imc)) (Obesidade II)"
            
        case 40..<50:
            resultadoIMC = "IMC: \(String(format:"%.2f", imc)) (Obesidade II)"
            
            
        default:
            resultadoIMC = "IMC:  \(String(format: "%.2f", imc)) (Obesidade Grave)"
        }
    }
}

// Explicaçao : O "IMC: \(String(format: "%.2f", imc))" é realizado pois demonstra que a porcentagem é feita pelo decimal. Por exemplo : "24.789 no formato de peso seria 24,78.




